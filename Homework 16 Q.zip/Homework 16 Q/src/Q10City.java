import java.util.Scanner;
public class Q10City {

// ---------------------Globle variable-------------------------------------------

    static String a="Ahmedabad";
    static String b="Bharuch";
    static String c="Chatisgardh";
    static String d="Dholera";
    static String e="Eddingburg";
    static String f="Faridabad";

//=======================Main method=========================================================
    public static void main(String arg[]) {
        char ch;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter any Charector a to f :");
        ch=scan.next().charAt(0);
//-------------------------If Else-------------------------------
        if (ch=='a')
        {
            System.out.println(a);

        } else if (ch=='b')
        {
            System.out.println(b);
        }
        else if(ch=='c')
        {
            System.out.println(c);
        }
        else if (ch=='d')
        {
            System.out.println(d);
        }
        else if (ch=='e')
        {
            System.out.println(e);
        }
        else if (ch=='f')
        {
            System.out.println(f);
        }
        else
        {
            System.out.println("Enter valid Charactor between a to f or in small case");
        }


    }
}